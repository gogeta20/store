<template>
  <Head>
    <Title>Posts</Title>
  </Head>

  <h2>Post Page</h2>

  <ul>
    <li>
      <NuxtLink to="/posts/1"> Primer Post </NuxtLink>
    </li>
    <li>
      <NuxtLink to="/posts/2"> Segundo Post </NuxtLink>
    </li>
    <li>
      <NuxtLink to="/posts/3"> Tercer Post </NuxtLink>
    </li>
  </ul>
</template>
