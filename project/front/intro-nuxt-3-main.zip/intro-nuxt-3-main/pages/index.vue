<template>
  <h1>Aprendiendo Nuxt</h1>
  <img src="/img/nuxt.svg" alt="SVG de Nuxt.js" />

  <p>
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis natus
    itaque, officia eius amet eum possimus enim nisi, inventore odit magni
    aspernatur cumque atque expedita beatae modi, temporibus a animi! Cupiditate
    eligendi explicabo neque, temporibus placeat libero, pariatur dolor
    doloribus fuga totam facilis incidunt obcaecati aperiam expedita natus magni
    mollitia ipsum sed qui officiis iure provident quasi doloremque ad? Dolore?
    Magnam, animi! Repellat incidunt quae nostrum facilis temporibus ipsum,
    delectus rerum numquam voluptas itaque laborum doloribus adipisci cupiditate
    nobis cumque ex quisquam veniam, excepturi tenetur iste vel. Dolorum,
    repellat ut. Ducimus inventore beatae delectus numquam facilis accusantium,
    et doloribus. Quaerat earum ducimus recusandae ullam. Atque ratione placeat,
    non sit amet labore possimus natus velit ipsum quis aut aliquam facere
    ipsam. Ea quasi inventore dicta a? Vero atque repudiandae nostrum dolore
    eveniet quos aperiam mollitia maiores voluptas sapiente! Vero dolorum quis
    illum optio suscipit veritatis consequatur magnam error, officiis neque
    laudantium? Quaerat sit unde placeat maxime velit quod perferendis
    distinctio deserunt? Sequi, quibusdam sunt? Minima odit, nisi maiores nobis
    et expedita aspernatur culpa ipsam reprehenderit ipsum exercitationem
    dolorem iure voluptas fugiat! Saepe nisi aut rerum adipisci similique ut
    nulla corrupti obcaecati voluptatum inventore, nobis id optio at! Magni vero
    nisi illo quam eos possimus suscipit voluptatibus, facere at minus sapiente
    beatae. Eum error quaerat quisquam, officia harum iste? Id adipisci ducimus
    et laudantium ut quam. Facere rerum quasi ipsa consequuntur quo error
    facilis, deleniti vitae corrupti. Earum praesentium ut nostrum ducimus?
    Facilis vero delectus sunt quam nulla obcaecati atque doloribus minus odio,
    temporibus magni eos quae ad illum vel odit molestias, non cupiditate et
    quasi, asperiores repudiandae ex nihil inventore? Delectus. Commodi eos
    alias sequi molestias error consectetur nulla? Eius cum, eaque, fugit
    delectus doloribus tenetur iste rem facilis fugiat ratione accusantium
    voluptates deserunt earum maxime dolorem. Nulla quia ullam voluptas.
  </p>
</template>

<script setup>
useHead({
  title: "Home",
});
</script>
