<template>
  <h1>Usando SSR en Vue 3</h1>

  <img src="/img/vue.svg" alt="Icono de Vue.js" />
</template>
